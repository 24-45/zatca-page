# دليل نشر الموقع على GitHub Pages 🚀

## الخطوة 1: إنشاء Repository جديد على GitHub

1. اذهب إلى [GitHub](https://github.com) وسجل الدخول
2. اضغط على زر **New Repository** (أو `+` في الأعلى)
3. اختر اسم للمستودع (مثل: `zatca-website`)
4. اجعله **Public** (عام)
5. لا تُضف README أو .gitignore (لدينا بالفعل)
6. اضغط **Create Repository**

## الخطوة 2: رفع المشروع للمرة الأولى

افتح Terminal في مجلد المشروع ونفذ الأوامر التالية:

```bash
# تهيئة Git في المجلد
git init

# إضافة جميع الملفات
git add .

# إنشاء أول commit
git commit -m "Initial commit: ZATCA website ready for GitHub Pages"

# ربط المشروع مع GitHub (استبدل USERNAME و REPO_NAME بمعلوماتك)
git remote add origin https://github.com/USERNAME/REPO_NAME.git

# رفع الملفات
git branch -M main
git push -u origin main
```

## الخطوة 3: تفعيل GitHub Pages

1. اذهب إلى صفحة Repository على GitHub
2. اضغط على **Settings** (الإعدادات)
3. من القائمة الجانبية اختر **Pages**
4. في قسم **Source**:
   - اختر Branch: `main`
   - اختر Folder: `/ (root)`
5. اضغط **Save**
6. انتظر بضع دقائق حتى يتم نشر الموقع
7. سيظهر رابط الموقع في الأعلى مثل:
   ```
   https://username.github.io/zatca-website/
   ```

## الخطوة 4: تحديث الموقع مستقبلاً

عند إجراء أي تعديلات على الملفات:

```bash
# إضافة التعديلات
git add .

# إنشاء commit جديد مع وصف التعديل
git commit -m "وصف التعديل الذي قمت به"

# رفع التعديلات
git push
```

بعد الدفع، سيتم تحديث الموقع على GitHub Pages تلقائياً خلال 1-2 دقيقة.

## ✅ قائمة التحقق النهائية

- [x] جميع الملفات منظمة في المجلدات الصحيحة
- [x] المسارات نسبية (css/style.css, js/script.js, images/...)
- [x] لا توجد ملفات backup أو زائدة
- [x] ملف README.md موجود
- [x] ملف .gitignore موجود

## 📁 هيكل المشروع النهائي

```
zatca/
├── index.html              ← الصفحة الرئيسية
├── README.md               ← وصف المشروع
├── .gitignore              ← تجاهل الملفات غير الضرورية
├── css/
│   └── style.css          ← جميع الأنماط
├── js/
│   └── script.js          ← جميع الوظائف
├── images/
│   ├── X.png
│   └── Zakat Tax.png
└── sections/
    ├── section6-new.html
    ├── zatca-fixed.html
    └── zatca-redesign.html
```

## 🔗 روابط مفيدة

- [GitHub Pages Documentation](https://docs.github.com/en/pages)
- [Git Basics](https://git-scm.com/book/en/v2/Getting-Started-Git-Basics)

## ⚠️ ملاحظات مهمة

1. **المسارات النسبية**: جميع الروابط تستخدم مسارات نسبية (بدون `/` في البداية)
2. **الأسماء**: تجنب المسافات أو الأحرف الخاصة في أسماء الملفات
3. **حجم الملفات**: GitHub Pages يدعم حتى 1 GB للمستودع
4. **HTTPS**: الموقع سيعمل تلقائياً على HTTPS

---

**بالتوفيق! 🎉**
